export const environment = {
  production: false,

  dialogflow: {
    angularBot: 'dd7cc499bf1147f78350d0eb8c48f230'
  }
};