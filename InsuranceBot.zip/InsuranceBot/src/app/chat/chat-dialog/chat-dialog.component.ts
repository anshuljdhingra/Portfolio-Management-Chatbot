import { Component, OnInit, DoCheck} from '@angular/core';
import { ChatService, Message } from '../../chat.service';
import { Observable } from 'rxjs';
import { scan } from 'rxjs/operators';

//import 'rxjs/add/operator/scan';


@Component({
  selector: 'chat-dialog',
  templateUrl: './chat-dialog.component.html',
  styleUrls: ['./chat-dialog.component.css']
})
export class ChatDialogComponent implements OnInit,DoCheck{
  //messages: any;
  messages: Observable<Message[]>;
  formValue: string;
  container: HTMLElement; 
  //const subject = new Rx.BehaviorSubject();
  
  constructor(public chat: ChatService) { }

  ngOnInit() {
    // appends to array after each new message is added to feedSource
    this.messages = this.chat.conversation.asObservable()
    .pipe(
      scan((acc, val) => acc.concat(val))
    )
      
}

ngDoCheck(){
    this.container = document.getElementById("msgContainer");
    this.container.scrollTop=this.container.scrollHeight;
    
  }

  sendMessage() {
    this.chat.converse(this.formValue);
    this.formValue = '';
       
  }

}