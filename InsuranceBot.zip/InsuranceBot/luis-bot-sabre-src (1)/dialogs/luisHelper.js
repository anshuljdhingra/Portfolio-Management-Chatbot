// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { LuisRecognizer } = require('botbuilder-ai');
const { ComponentDialog, DialogTurnStatus } = require('botbuilder-dialogs');

class LuisHelper {
    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {*} logger
     * @param {TurnContext} context
     */
    static async executeLuisQuery(logger, context) {
        
       // async onTurn(context) {

        
        try {
            const recognizer = new LuisRecognizer({
                applicationId: process.env.LuisAppId,
                endpointKey: process.env.LuisAPIKey,
                endpoint: `https://${ process.env.LuisAPIHostName }`
            }, {}, true);

            const recognizerResult = await recognizer.recognize(context);

            const intent = LuisRecognizer.topIntent(recognizerResult);

            if (intent === 'SampleQuery') {
    // We need to get the result from the LUIS JSON which at every level returns an array

    // bookingDetails.destination = LuisHelper.parseCompositeEntity(recognizerResult, 'To', 'Airport');
    // bookingDetails.origin = LuisHelper.parseCompositeEntity(recognizerResult, 'From', 'Airport');

    // This value will be a TIMEX. And we are only interested in a Date so grab the first result and drop the Time part.
    // TIMEX is a format that represents DateTime expressions that include some ambiguity. e.g. missing a Year.
    // bookingDetails.travelDate = LuisHelper.parseDatetimeEntity(recognizerResult);
}
         


}
catch (err) {
            logger.warn(`LUIS Exception: ${ err } Check your LUIS configuration`);
        }
        return bookingDetails;

    }

    
}

module.exports.LuisHelper = LuisHelper;











// if (intent === 'SampleQuery') {
//     // We need to get the result from the LUIS JSON which at every level returns an array

//     // bookingDetails.destination = LuisHelper.parseCompositeEntity(recognizerResult, 'To', 'Airport');
//     // bookingDetails.origin = LuisHelper.parseCompositeEntity(recognizerResult, 'From', 'Airport');

//     // This value will be a TIMEX. And we are only interested in a Date so grab the first result and drop the Time part.
//     // TIMEX is a format that represents DateTime expressions that include some ambiguity. e.g. missing a Year.
//     // bookingDetails.travelDate = LuisHelper.parseDatetimeEntity(recognizerResult);
// }
// } catch (err) {
// logger.warn(`LUIS Exception: ${ err } Check your LUIS configuration`);
// }
// return bookingDetails;

// static parseCompositeEntity(result, compositeName, entityName) {
    //     const compositeEntity = result.entities[compositeName];
    //     if (!compositeEntity || !compositeEntity[0]) return undefined;

    //     const entity = compositeEntity[0][entityName];
    //     if (!entity || !entity[0]) return undefined;

    //     const entityValue = entity[0][0];
    //     return entityValue;
    // }

    // static parseDatetimeEntity(result) {
    //     const datetimeEntity = result.entities['datetime'];
    //     if (!datetimeEntity || !datetimeEntity[0]) return undefined;

    //     const timex = datetimeEntity[0]['timex'];
    //     if (!timex || !timex[0]) return undefined;

    //     const datetime = timex[0].split('T')[0];
    //     return datetime;
    // }


















//       // Supported LUIS Intents
//       const GREETING_INTENT = 'Greeting';
//       const CANCEL_INTENT = 'Cancel';
//       const HELP_INTENT = 'Help';
//       const NONE_INTENT = 'None';
//       const SAMPLE_QUERY = 'SampleQuery'; // new intent
//       const END_CHAT  = 'EndChat '; // new intent
//       const WELCOME = 'Welcome'

//   try {
//       const recognizer = new LuisRecognizer({
//           applicationId: process.env.LuisAppId,
//           endpointKey: process.env.LuisAPIKey,
//           endpoint: `https://${ process.env.LuisAPIHostName }`
//       }, {}, true);

//       const recognizerResult = await recognizer.recognize(context);

//       const topIntent = LuisRecognizer.topIntent(recognizerResult);

//       const dc = await this.dialogs.createContext(context);
      
//       const interrupted = await this.isTurnInterrupted(dc, recognizerResult);
//       if(interrupted) {
//        return;
//    }

//    // Continue the current dialog
//   const dialogResult = await dc.continue();

//   switch(dialogResult.status) {
//       case DialogTurnStatus.empty:
//           switch (topIntent) {
//               case GREETING_INTENT:
//                   await dc.begin('Hi I am Electra!');
//                   break;

//               case SAMPLE_QUERY: 
             
//                   await dc.context.sendActivity(`Look into the carrier table for the error`);
//                   break;
             
//                   // New HomeAutomation.TurnOff intent

//               case WELCOME: 
             
//                   await dc.context.sendActivity(`Hi, I am electra! I am Sabre's Digi-assistant`);
//                   break;

//               case END_CHAT: 
             
//                   await dc.context.sendActivity(`Okay, I was happy to help you.`);
//                   break;

//               case CANCEL_INTENT:
//                   await dc.context.sendActivity('See ya!');
//                   break;

//               case HELP_INTENT:
//                   await dc.context.sendActivity('Thank you, for calling me. I here to assist you. Ask me about partnership queries');
//                   break;

//               case NONE_INTENT:
                  
//               default:
//                   await dc.context.sendActivity(`Sorry, I am still Learning. topIntent ${topIntent}`);
//                   break;
//   }

// case DialogTurnStatus.waiting:
//   // The active dialog is waiting for a response from the user, so do nothing
// break;

// case DialogTurnStatus.complete:
//   await dc.end();
//   break;

// default:
//   await dc.cancelAll();
//   break;

// }